package t3a6;
import java.util.Scanner;
/**}* @author Raul*/
public class Empleados {
    private String nombre;
    private String apellidoP;
    private String apellidoM;
    private String rfc;
    private String curp;
    private String email;
    private String telefono;
    private int noContrato;

    public Empleados() {
    }

    
    public Empleados(String nombre, String apellidoP, String apellidoM, String rfc, String curp, String email, String telefono, int noContrato) {
        this.nombre = nombre;
        this.apellidoP = apellidoP;
        this.apellidoM = apellidoM;
        this.rfc = rfc;
        this.rfc = rfc;
        this.curp = curp;
        this.email = email;
        this.telefono = telefono;
        
    }

    @Override
    public String toString() {
        return "Nombre: "+nombre+" "+apellidoP+" "+apellidoM
                + "\nRfc: "+rfc
                + "\nCurp: "+curp
                + "\nCorreo: "+email
                + "\nNumero de telefono: "+telefono
                + "\nNumero de contrato: "+noContrato;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoP() {
        return apellidoP;
    }

    public void setApellidoP(String apellidoP) {
        this.apellidoP = apellidoP;
    }

    public String getApellidoM() {
        return apellidoM;
    }

    public void setApellidoM(String apellidoM) {
        this.apellidoM = apellidoM;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getCurp() {
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = curp;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public int getNoContrato() {
        return noContrato;
    }

    public void setNoContrato(int noContrato) {
        this.noContrato = noContrato;
    }

    

    
    
}

