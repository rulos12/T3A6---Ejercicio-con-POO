package t3a6;

import java.util.Scanner;

/**
 * ** @author Raul
 */
public class T3A6 {

    public static void main(String[] args) {
        proceso();
    }

    public static void proceso() {
        Scanner obj = new Scanner(System.in);
        Empleados empleado = new Empleados();
        Nomina nomina = new Nomina();
        
        System.out.println("Fabrica textil Maquiladora");
        for (int j=1; j<=3; j++){
            
            if(j==1){
                System.out.println("Sucursal Teziutlan");
            }
            else if(j==2){
                System.out.println("Sucursal CDMX");
            }
            else if(j==3){
                System.out.println("Sucursal Malecon Veracruz");
            }
        System.out.println("Ingrese la cantidad de empleados a los que necesita calcular su nomina");
        int empleados = obj.nextInt();
        nomina.setEmpleados(empleados);
        for (int i = 1; i <= empleados; i++) {
            System.out.println("Ingrese el numero de contrato: ");
            int noContrato=obj.nextInt();
            empleado.setNoContrato(noContrato);
            System.out.println("Ingrese los años de antiguedad del trabajador: ");
            int años=obj.nextInt();
            nomina.setAños(años);
            if(nomina.getAños()>=3){
                System.out.println("Ingrese el area del trabajador: "
                    + "\n1.-Area Administrativa "
                    + "\n2.-Area Financiera"
                    + "\n3.-Area de Produccion "
                    + "\n4.-Area de Marketing"
                    + "\nDijite un numero");
            int tipoEmpleado = obj.nextInt();
            nomina.setTipoEmpleado(tipoEmpleado);
            }
            System.out.println("Ingrese las horas laboradas al dia del trabajador: ");
            float horas=obj.nextInt();
            nomina.setHoras(horas);
            System.out.println("Ingrese el salario diario del trabajador: ");
            float salario=obj.nextFloat();
            nomina.setSalario(salario);
            System.out.println("Ingrese el nombre del trabajador: ");
            String nombre = obj.next();
            empleado.setNombre(nombre);
            System.out.println("Ingrese el apellido paterno: ");
            String apellidoP = obj.next();
            empleado.setApellidoP(apellidoP);
            System.out.println("Ingrese el apellido materno: ");
            String apellidoM = obj.next();
            empleado.setApellidoM(apellidoM);
            System.out.println("Ingrese el RFC del trabajador: ");
            String rfc = obj.next();
            empleado.setRfc(rfc);
            System.out.println("Ingrese la CURP del trabajador: ");
            String curp = obj.next();
            empleado.setCurp(curp);
            System.out.println("Ingrese el correo del trabajador: ");
            String email = obj.next();
            empleado.setEmail(email);
            System.out.println("Ingrese el numero de telefono del trabajador");
            String telefono = obj.next();
            empleado.setTelefono(telefono);
            System.out.println(empleado.toString());
            nomina.setHoras(horas);
            nomina.setSalarioBruto(salario);
            System.out.println("Le pagan "+nomina.getHoras()+" por hora");
            System.out.println("Su salario bruto al mes es de: " +nomina.getSalarioBruto());
            nomina.calcular();
            
        }
        }

    }

}
