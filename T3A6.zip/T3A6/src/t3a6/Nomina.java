package t3a6;

/**
 * ** @author Raul
 */
public class Nomina {

    private float salarioBruto;
    private float salarioFinal;
    private float horas;
    private int años;
    private int tipoEmpleado;
    private int empleados;
    private float isr;
    private float salario;

    public void calcular() {
        if (getAños() >= 3 && getAños() <= 5) {
            if (getSalarioBruto() >= 0.01 && getSalarioBruto() <= 318.00) {//primero

                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 0.01) * 0.0192) + 0.00);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.07) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad y 4% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 0.01) * 0.0192) + 0.00);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.03) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad");

                }
            }
            if (getSalarioBruto() >= 318.01 && getSalarioBruto() <= 2699.40) {//segundo

                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 318.01) * 0.064) + 6.15);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.07) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad y 4% por ser administrador");

                } else {
                    isr = (float) (((salarioBruto - 318.01) * 0.064) + 6.15);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.03) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad");

                }
            }
            if (getSalarioBruto() >= 2699.41 && getSalarioBruto() <= 4744.05) {//tercero

                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 2699.41) * 0.1088) + 158.55);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.07) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad y 4% por ser administrador");

                } else {
                    isr = (float) (((salarioBruto - 2699.41) * 0.1088) + 158.55);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.03) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad");

                }
            }
            if (getSalarioBruto() >= 4744.06 && getSalarioBruto() <= 5514.17) {//cuarto

                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 4744.06) * 0.16) + 381.00);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.07) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad y 4% por ser administrador");

                } else {
                    isr = (float) (((salarioBruto - 4744.06) * 0.16) + 381.00);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.03) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad");

                }
            }
            if (getSalarioBruto() >= 5514.76 && getSalarioBruto() <= 6602.70) {//quinto
                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 5514.76) * 0.1792) + 504.30);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.07) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad y 4% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 5514.76) * 0.1792) + 504.30);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.03) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());

                }
                System.out.println("Se le asigno un bono del 3% por sus años de antiguedad");
            }
            if (getSalarioBruto() >= 6602.71 && getSalarioBruto() <= 13316.70) {//sexto
                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 6602.71) * 0.2136) + 699.30);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.07) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad y 4% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 6602.71) * 0.2136) + 699.30);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.03) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad");
                }
            }
            if (getSalarioBruto() >= 13316.71 && getSalarioBruto() <= 20988.90) {//sectimo
                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 13316.71) * 0.2352) + 2133.30);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.07) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad y 4% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 13316.71) * 0.2352) + 2133.30);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.03) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad");
                }
            }
            if (getSalarioBruto() >= 20988.91 && getSalarioBruto() <= 40071.30) {//octavo

                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 20988.91) * 0.3) + 3937.80);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.07) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad y 4% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 20988.91) * 0.3) + 3937.80);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.03) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad");
                }
            }

        } else if (getAños() >= 6 && getAños() >= 10) {
            if (getSalarioBruto() >= 0.01 && getSalarioBruto() <= 318.00) {//primero

                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 0.01) * 0.0192) + 0.00);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.2) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad y 12% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 0.01) * 0.0192) + 0.00);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.08) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad");
                }
            }
            if (getSalarioBruto() >= 318.01 && getSalarioBruto() <= 2699.40) {//segundo

                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 318.01) * 0.064) + 6.15);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.2) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad y 12% por ser administrador");
                    System.out.println("Se le asigno un bono del 3% por sus años de antiguedad y 4% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 318.01) * 0.064) + 6.15);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.08) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad");
                }
            }
            if (getSalarioBruto() >= 2699.41 && getSalarioBruto() <= 4744.05) {//tercero

                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 2699.41) * 0.1088) + 158.55);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.2) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad y 12% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 2699.41) * 0.1088) + 158.55);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.08) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad");
                }
            }
            if (getSalarioBruto() >= 4744.06 && getSalarioBruto() <= 5514.17) {//cuarto

                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 4744.06) * 0.16) + 381.00);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.2) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad y 12% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 4744.06) * 0.16) + 381.00);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.08) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad");
                }
            }
            if (getSalarioBruto() >= 5514.76 && getSalarioBruto() <= 6602.70) {//quinto
                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 5514.76) * 0.1792) + 504.30);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.2) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad y 12% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 5514.76) * 0.1792) + 504.30);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.08) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad");
                }
            }
            if (getSalarioBruto() >= 6602.71 && getSalarioBruto() <= 13316.70) {//sexto
                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 6602.71) * 0.2136) + 699.30);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.2) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad y 12% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 6602.71) * 0.2136) + 699.30);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.08) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad");
                }
            }
            if (getSalarioBruto() >= 13316.71 && getSalarioBruto() <= 20988.90) {//sectimo
                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 13316.71) * 0.2352) + 2133.30);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.2) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad y 12% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 13316.71) * 0.2352) + 2133.30);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.08) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad");
                }
            }
            if (getSalarioBruto() >= 20988.91 && getSalarioBruto() <= 40071.30) {//octavo

                if (getTipoEmpleado() == 1) {
                    isr = (float) (((getSalarioBruto() - 20988.91) * 0.3) + 3937.80);
                    salarioFinal = (float) (((getSalarioBruto() - getIsr()) * 0.2) + getSalarioBruto());
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad y 12% por ser administrador");
                } else {
                    isr = (float) (((salarioBruto - 20988.91) * 0.3) + 3937.80);
                    salarioFinal = (float) (((salarioBruto - isr) * 0.08) + salarioBruto);
                    System.out.println("ISR: " + getIsr());

                    System.out.println("Salario final: " + getSalarioFinal());
                    System.out.println("Se le asigno un bono del 8% por sus años de antiguedad");
                }
            }

        } else {
            if (getSalarioBruto() >= 0.01 && getSalarioBruto() <= 318.00) {//primero

                isr = (float) (((salarioBruto - 0.01) * 0.0192) + 0.00);
                salarioFinal = (float) (salarioBruto - isr);
                System.out.println("ISR: " + getIsr());

                System.out.println("Salario final: " + getSalarioFinal());

            }
            if (getSalarioBruto() >= 318.01 && getSalarioBruto() <= 2699.40) {//segundo

                isr = (float) (((salarioBruto - 318.01) * 0.064) + 6.15);
                salarioFinal = (float) (salarioBruto - isr);
                System.out.println("ISR: " + getIsr());

                System.out.println("Salario final: " + getSalarioFinal());

            }
            if (getSalarioBruto() >= 2699.41 && getSalarioBruto() <= 4744.05) {//tercero

                isr = (float) (((salarioBruto - 2699.41) * 0.1088) + 158.55);
                salarioFinal = (float) (salarioBruto - isr);
                System.out.println("ISR: " + getIsr());

                System.out.println("Salario final: " + getSalarioFinal());

            }
            if (getSalarioBruto() >= 4744.06 && getSalarioBruto() <= 5514.17) {//cuarto

                isr = (float) (((salarioBruto - 4744.06) * 0.16) + 381.00);
                salarioFinal = (float) (salarioBruto - isr);
                System.out.println("ISR: " + getIsr());

                System.out.println("Salario final: " + getSalarioFinal());

            }
            if (getSalarioBruto() >= 5514.76 && getSalarioBruto() <= 6602.70) {//quinto

                isr = (float) (((salarioBruto - 5514.76) * 0.1792) + 504.30);
                salarioFinal = (float) (salarioBruto - isr);
                System.out.println("ISR: " + getIsr());

                System.out.println("Salario final: " + getSalarioFinal());

            }
            if (getSalarioBruto() >= 6602.71 && getSalarioBruto() <= 13316.70) {//sexto

                isr = (float) (((salarioBruto - 6602.71) * 0.2136) + 699.30);
                salarioFinal = (float) (salarioBruto - isr);
                System.out.println("ISR: " + getIsr());

                System.out.println("Salario final: " + getSalarioFinal());

            }
            if (getSalarioBruto() >= 13316.71 && getSalarioBruto() <= 20988.90) {//sectimo

                isr = (float) (((salarioBruto - 13316.71) * 0.2352) + 2133.30);
                salarioFinal = (float) (salarioBruto - isr);
                System.out.println("ISR: " + getIsr());

                System.out.println("Salario final: " + getSalarioFinal());

            }
            if (getSalarioBruto() >= 20988.91 && getSalarioBruto() <= 40071.30) {//octavo

                isr = (float) (((salarioBruto - 20988.91) * 0.3) + 3937.80);
                salarioFinal = (float) (salarioBruto - isr);
                System.out.println("ISR: " + getIsr());

                System.out.println("Salario final: " + getSalarioFinal());

            }
        }
    }

    public Nomina() {
    }

    public Nomina(float salarioBruto, float horas, int años, int tipoEmpleado, int empleados, float isr, float salario) {
        this.salarioBruto = salarioBruto;
        this.horas = horas;
        this.años = años;
        this.tipoEmpleado = tipoEmpleado;
        this.empleados = empleados;
        this.isr = isr;
        this.salario = salario;
        this.salarioFinal = salarioFinal;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public float getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(float salarioBruto) {
        this.salarioBruto = (salario * 7) * 4;
    }

    public float getSalarioFinal() {
        return salarioFinal;
    }

    public void setSalarioFinal(float salarioFinal) {
        this.salarioFinal = salarioFinal;
    }

    public float getHoras() {
        return horas;
    }

    public void setHoras(float horas) {
        this.horas = (salario / horas);
    }

    public int getAños() {
        return años;
    }

    public void setAños(int años) {
        this.años = años;
    }

    public int getTipoEmpleado() {
        return tipoEmpleado;
    }

    public void setTipoEmpleado(int tipoEmpleado) {
        this.tipoEmpleado = tipoEmpleado;
    }

    public int getEmpleados() {
        return empleados;
    }

    public void setEmpleados(int empleados) {
        this.empleados = empleados;
    }

    public float getIsr() {
        return isr;
    }

    public void setIsr(float isr) {
        this.isr = isr;
    }

}
